-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Aug 28, 2015 at 11:37 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `outlets`
--

CREATE TABLE `outlets` (
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `outlets`
--

INSERT INTO `outlets` (`store_id`, `brand_id`, `id`) VALUES
(90, 58, 1),
(91, 59, 2),
(92, 59, 3),
(103, 67, 4),
(104, 68, 5),
(105, 68, 6),
(116, 76, 7),
(117, 77, 8),
(118, 77, 9),
(129, 85, 10),
(130, 86, 11),
(131, 86, 12),
(142, 87, 13),
(144, 97, 14),
(145, 98, 15),
(146, 98, 16),
(157, 99, 17),
(159, 109, 18),
(160, 110, 19),
(161, 110, 20),
(172, 111, 21),
(173, 112, 22),
(174, 121, 23),
(175, 122, 24),
(176, 122, 25),
(187, 123, 26),
(188, 124, 27),
(189, 133, 28),
(190, 134, 29),
(191, 134, 30),
(202, 135, 31),
(203, 136, 32),
(203, 137, 33),
(204, 145, 34),
(205, 146, 35),
(206, 146, 36),
(217, 147, 37),
(218, 148, 38),
(218, 149, 39),
(219, 157, 40),
(220, 158, 41),
(221, 158, 42),
(231, 167, 44),
(232, 168, 45),
(233, 168, 46),
(243, 170, 48),
(244, 171, 49),
(244, 172, 50),
(245, 180, 51),
(246, 181, 52),
(247, 181, 53),
(257, 183, 55),
(258, 184, 56),
(258, 185, 57),
(259, 193, 58),
(260, 194, 59),
(261, 194, 60),
(271, 196, 62),
(272, 197, 63),
(272, 198, 64),
(273, 206, 65),
(274, 207, 66),
(275, 207, 67),
(286, 210, 70),
(287, 211, 71),
(287, 212, 72);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `outlets`
--
ALTER TABLE `outlets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=213;
--
-- AUTO_INCREMENT for table `outlets`
--
ALTER TABLE `outlets`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=288;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
